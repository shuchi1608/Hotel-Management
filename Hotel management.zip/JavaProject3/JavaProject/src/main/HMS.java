package src.main;//to specify location of the current file, we create a package

import java.util.*;
import src.packages.beautify.*;//importing rest of the packages
import src.packages.dataclass.hotel.*;//importing checkout and bookroom using *
import src.packages.login.*;
import src.validations.Validate;

public class HMS{
        public static void main(String[] args) throws Exception{//ignores all exceptions
		Scanner sc = new Scanner(System.in);
                String name = " ";
                int choice;

		Welcome.welcome();//welcome is a static function of class Welcome so we can call it directly without creating an object

		System.out.println("Press 1 to Login");
		System.out.println("Press 2 to SignUp");

		choice=sc.nextInt();

		if(choice==1)
			name = Login.login();
		else{								
                        Login.signup();
                        name = Login.login();//login returns user_id which gets stored in name
		}

		do{
                        System.out.println("\nEnter your choice :\n1.Display room details\n2.Display room availability \n3.Book a room\n4.Checkout\n5.Exit\n");
        choice = sc.nextInt();
        switch(choice){
            case 1:
                    displayDetails.displayMyRooms(name);
                    break;

            case 2:
                    displayDetails.displayAvailableRooms();
                    break;

            case 3: 
                    bookRoom.book(name);                     
                    break;
            case 4:
                    Checkout.checkout(name);
                    break;

            case 5: System.exit(0);

            default:System.out.println("Invalid choice");            	
            	    break;                             
                }
        }while(choice != 4);	
        }
}