package src.validations;

import java.util.*;

public class Validate{

	public static boolean ValidPass(String pass){
		if(pass.length()>7){
			if(CheckPass(pass))
			{
				System.out.println("Valid Password!");
				return true;				
			}
			else
			{	
				return false;
							}
			}
		else
		{
			System.out.println("Password is too small!");
			
			return false;
		}
	}
	
	public static boolean CheckPass(String pass){
		boolean Hasnum=false;
		boolean Hascap=false;
		char c;
		for(int i=0;i<pass.length();i++)
		{
			c=pass.charAt(i);
			if(Character.isDigit(c))
			{
				Hasnum=true;
			}
			else if(Character.isUpperCase(c))
			{
				Hascap=true;
			}
			if(Hasnum && Hascap){
				return true;
			}
		}
		return false;
	}
}