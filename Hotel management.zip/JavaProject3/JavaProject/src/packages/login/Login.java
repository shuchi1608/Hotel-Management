package src.packages.login;//to specify location of the current file, we create a package


import src.validations.Validate;
import java.util.*;//imports scanner and random classes.
import java.io.*;//imports classes for file handling(to read and write files)

public class Login{

	static Scanner sc = new Scanner(System.in);//static functions can only call static variables 
	static Random r = new Random();
	static File f = new File("C:/Users/Yashita/Desktop/JavaProject3/JavaProject/database/Login.txt");//opens Login.txt

	public static void signup() throws Exception{
		System.out.println("---------------SIGN UP PAGE---------------/t");
		String id, rand, pnum, pass;
		FileWriter fw = new FileWriter(f, true);//initialises object fw of class FileWriter to write in file f in append mode(starts writitng from the end instead of overwriting)
		do{
			System.out.println("Enter your name : ");
			id=sc.nextLine();
			rand = String.format("%04d", r.nextInt(10000));
			id += "#" + rand;
			System.out.println("Enter your phone number : ");
			pnum=sc.nextLine();
			System.out.println("Create a password(Must be at least 8 characters, have one capital letter and one digit) : ");
			pass=sc.nextLine();
			if(!(Validate.ValidPass(pass))){
				System.out.println("Invalid Pass, Try Again!");
			}
		}while(!(Validate.ValidPass(pass)));

		if((Validate.ValidPass(pass)))
		{
		System.out.println("New User_Id Created! Log In using ID " + id + " to start booking your room!");
		fw.write(id + "," + pass + "\n");
		}
		fw.close();
	}

	public static String login() throws Exception{
		
		boolean flag = true;
		String namechk = " ", passchk = " ";

		do{
		System.out.println("---------------LOG IN PAGE---------------");

		System.out.println("Enter your name(User_Id) : ");
		namechk = sc.nextLine();
		System.out.println("Enter password : ");
		passchk = sc.nextLine();

		BufferedReader br = new BufferedReader(new FileReader(f));
		String temp1, temp2[];
		while((temp1 = br.readLine()) != null){
			temp2 = temp1.split(",");
			if((temp2[0].equals(namechk)) && (temp2[1].equals(passchk))){
				System.out.println("Successfully Logged In!");
				flag =  false;
			}
		}
		if(flag){
			System.out.println("Invalid!");
		}
	}while(flag);
	return namechk;
	}

	public static void main(String args[]){
		try{String id = signup();
		login();}catch(Exception e){System.out.println(e);}
	}
}

