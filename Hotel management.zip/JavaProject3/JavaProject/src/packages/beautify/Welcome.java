package src.packages.beautify;

public class Welcome{
    public static void welcome(){
        System.out.println("        |-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-| ");
        System.out.println("        |                                           | ");
        System.out.println("        |                 WELCOME                   | ");
        System.out.println("        |                   TO                      | ");
        System.out.println("        |                  HOTEL                    | ");
        System.out.println("        |                   Y&S                     | ");
        System.out.println("        |                                           | ");
        System.out.println("        |-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-| ");
    }

    public static void main(String args[]){
        welcome();
    }
}