package src.packages.beautify;

public class Bill {
    public static void bill(int net_price, String name, String rtype, String rsize){
        
        System.out.println("|----------BILL-----------|");
        System.out.println("|                         |");
        System.out.println("|Room - " + rsize + ", " + rtype + "    |");
        System.out.println("|Price : " + net_price + "             |");
        System.out.println("|Extra : None             |");
        System.out.println("|GST : 5% = " + net_price/20 + "           |");
        System.out.println("|Total : " + net_price*1.05 + "           |");
        System.out.println("|  Hope To See You Again  |");
        System.out.println("          " + name + "         ");
        System.out.println("|-------------------------|");
    }

    public static void main(String args[]){
        bill(7000, "Yashita#2011", "Deluxe", "Single");
    }
}