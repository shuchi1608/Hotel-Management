package src.packages.beautify;

import java.io.*;

public class displayDetails{
	public static void displayMyRooms(String id) throws Exception{
		File read_file = new File("C:/Users/Yashita/Desktop/JavaProject3/JavaProject/database/OccupiedRooms.txt");
		BufferedReader br = new BufferedReader(new FileReader(read_file));
		String temp1;
		String temp2[];
		int count = 0;

		while((temp1 = br.readLine()) != null){
			temp2 = temp1.split(",");
			if (temp2[1].equals(id)){
				count++;
				System.out.print("Room No:" + temp2[0] + "\nUser ID: " + temp2[1] + "\nRoom Type: " + temp2[2] + "\nRoom Size: " + temp2[3]);
				System.out.println();
			}
		}

		if(count == 0){
			System.out.println("No rooms are booked under this name!");
		}

		br.close();
	}

	public static void displayAvailableRooms() throws Exception{
		File read_file = new File("C:/Users/Yashita/Desktop/JavaProject3/JavaProject/database/EmptyRooms.txt");
		BufferedReader br = new BufferedReader(new FileReader(read_file));
		String temp1;
		String temp2[];
		int DS = 0;
		int DD = 0;
		int LS = 0;
		int LD = 0;

		while((temp1 = br.readLine()) != null){
			temp2 = temp1.split(",");			
			if(temp2[1].equals("Deluxe") && temp2[2].equals("Single")){
				DS++;
			}

			else if(temp2[1].equals("Deluxe") && temp2[2].equals("Double")){
				DD++;
			}

			else if(temp2[1].equals("Luxury") && temp2[2].equals("Single")){
				LS++;
			}

			else if(temp2[1].equals("Luxury") && temp2[2].equals("Double")){
				LD++;
			}				
		}

		System.out.println("Deluxe, Single : " + DS);
		System.out.println("Deluxe, Double : " + DD);
		System.out.println("Luxury, Single : " + LS);
		System.out.println("Luxury, Double : " + LD);

		br.close();
	}

	public static void main(String[] args){
		try{
			displayAvailableRooms();
		}catch(Exception e){
			System.out.println(e);
		}
	}
}