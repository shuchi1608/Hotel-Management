package src.packages.dataclass.hotel;

import java.io.*;
import src.packages.beautify.*;

public class Checkout {
    public static void checkout(String name) throws Exception{
        File f = new File("C:/Users/Yashita/Desktop/JavaProject3/JavaProject/database/OccupiedRooms.txt");
        BufferedReader br = new BufferedReader(new FileReader(f));
        File newFile = new File("C:/Users/Yashita/Desktop/JavaProject3/JavaProject/database/temp.txt");
        FileWriter fw = new FileWriter(newFile);
        int rType = 0, rSize = 0;
        String temp1, temp2[] = {""};
        int net_price = 0;

        while((temp1 = br.readLine()) != null){
            temp2 = temp1.split(",");

            if(temp2[1].equals(name)){

                if(temp2[2].equals("Deluxe")){
                    rType = 5;
                }
                else{
                    rType = 7;
                }    
                if(temp2[3].equals("Single")){
                    rSize = 500;
                }
                else{
                    rSize = 700;
                }
                net_price += rType * rSize;
            }
        }

        Bill.bill(net_price, name.split("#")[0], temp2[2], temp2[3]);
    }

    public static void main(String args[]){
        try{checkout("Yashu");}catch(Exception e){System.out.println(e);}
    }
}
