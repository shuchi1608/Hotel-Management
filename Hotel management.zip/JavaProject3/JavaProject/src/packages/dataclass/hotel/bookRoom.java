package src.packages.dataclass.hotel;

import java.util.*;
import java.io.*;

public class bookRoom {
    public static void book(String name) throws Exception{
        Scanner sc = new Scanner(System.in);
        Random r = new Random();
        System.out.println("\nChoose room type :\n1.Luxury Room \n2.Deluxe Room");
        int ch = sc.nextInt();
        String rType = " ";
        if(ch == 1){
            rType = "Luxury";
        }
        else{
            rType = "Deluxe";
        }

        System.out.println("\n1.Single Room\n2.Double Room");
        ch = sc.nextInt();
        String rSize = " ";
        if(ch == 1){
            rSize = "Single";
        }
        else{
            rSize = "Double";
        }

        File read_file = new File("C:/Users/Yashita/Desktop/JavaProject3/JavaProject/database/EmptyRooms.txt");
        BufferedReader br = new BufferedReader(new FileReader(read_file));
        String temp1;
        String temp2[] = {" "};
        String room_numbers[] = new String[10];
        int i = 0;

        while((temp1 = br.readLine()) != null){
            temp2 = temp1.split(",");
            if (temp2[1].equals(rType) && temp2[2].equals(rSize)){
                room_numbers[i] = temp2[0];
                i++;
            }
        }
        if(room_numbers[0] == null){
            System.out.println("No Rooms Of This Type Available, Try Another!");
            return;
        }

        br.close();
        
        File rewrite_file = new File("C:/Users/Yashita/Desktop/JavaProject3/JavaProject/database/temp.txt");
        BufferedReader br_new = new BufferedReader(new FileReader(read_file));
        FileWriter ifile = new FileWriter(rewrite_file);
        int rand = (r.nextInt(temp2.length));
            
        while((temp1 = br_new.readLine()) != null){
            temp2 = temp1.split(",");
            if (temp2[0].equals(room_numbers[rand])){
                continue;
            }
            ifile.write(temp2[0] + "," + temp2[1] + "," + temp2[2] + "\n");
        }


        br_new.close();
        ifile.close();
        read_file.delete();
        rewrite_file.renameTo(read_file);

        System.out.println("Your room has been booked!");

        File newFile = new File("C:/Users/Yashita/Desktop/JavaProject3/JavaProject/database/OccupiedRooms.txt");
        FileWriter ofile = new FileWriter(newFile, true);
        ofile.write(room_numbers[rand] + "," + name + "," + rType + "," + rSize + "\n");
        ofile.close();
    }

    public static void main(String args[]){
        try{book("Yashu");}catch(Exception e){System.out.println(e);}
    }
}
